<?php

namespace App\Exceptions;

use Exception;

class DepenseException extends Exception
{
    //
}
