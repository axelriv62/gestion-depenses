<?php

namespace App\Exceptions;

use Exception;

class PersonneNotFoundException extends Exception {
    //
}
