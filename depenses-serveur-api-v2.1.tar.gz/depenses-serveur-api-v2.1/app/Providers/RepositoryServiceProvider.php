<?php

namespace App\Providers;

use App\Repositories\DepenseRepository;
use App\Repositories\PersonneRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     */
    public function register(): void
    {
        $this->app->singleton(DepenseRepository::class, function ($app) {
            return new DepenseRepository();
        });
        $this->app->singleton(PersonneRepository::class,function ($app) {
            return new PersonneRepository();
        });
    }

    /**
     * Bootstrap services.
     */
    public function boot(): void
    {
        //
    }
}
