<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Personne extends Model {
    public $timestamps = false;

    protected $guarded = ['id'];

    public function depenses() {
        return $this->hasMany(Depense::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }
}
