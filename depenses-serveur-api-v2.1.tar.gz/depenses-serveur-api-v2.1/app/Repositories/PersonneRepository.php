<?php

namespace App\Repositories;

use App\Exceptions\PersonneNotFoundException;
use App\Models\Personne;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class PersonneRepository {
    /**
     * Create a new class instance.
     */
    public function __construct() {
        //
    }

    /**
     * Retrieve a collection of Personne models based on the provided parameters.
     *
     * @param array $params Optional parameters for filtering and sorting the results.
     *                      - 'sort' (string): The column to sort by.
     *                      - 'order' (string): The sort direction ('asc' or 'desc'). Defaults to 'asc'.
     *                      - 'search' (string): A search term to filter by the 'nom' column.
     *                      - 'horsLimite' (bool): If set, filters Personne models where the sum of related 'depenses' is less than the 'plafond'.
     * @return Collection A collection of Personne models.
     */
    public function getPersonnes(array $params = []): Collection {
        $query = Personne::query();
        if (isset($params['sort'])) {
            $query->orderBy($params['sort'], $params['order'] ?? 'asc');
        }
        if (isset($params['search'])) {
            $query->where('nom', 'like', '%' . $params['search'] . '%');
        }
        if (isset($params['horsLimite'])) {
            $query->where('plafond', '<', function ($query) {
                $query->select(DB::raw('sum(d.montant)'))
                    ->from('depenses as d')
                    ->whereColumn('d.personne_id', 'personnes.id');
            });
        }
        return $query->get();
    }

    /**
     * Retrieve a Personne model by its ID.
     *
     * @param int $id The ID of the Personne to retrieve.
     * @return Personne The retrieved Personne model.
     * @throws PersonneNotFoundException If no Personne is found with the given ID.
     */
    public function getPersonne(int $id): Personne {
        try {
            return Personne::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            throw new PersonneNotFoundException();
        }
        return $personne;
    }
}
