<?php

namespace App\Repositories;

use App\Exceptions\DepenseException;
use App\Models\Depense;
use Illuminate\Support\Facades\Gate;


class DepenseRepository {
    /**
     * Create a new class instance.
     */
    public function __construct() {
        //
    }

    public function depensesOfPersonneId(int $id) {
        if (request()->user()->cannot('viewAny', Depense::class)) {
            throw new DepenseException('You are not authorized to view these depenses', 403);
        }
        return Depense::where('personne_id', $id)->get();
    }

    public function montantDepensesOfPersonneId(int $id) {
        return Depense::where('personne_id', $id)->sum('montant');
    }

    public function store(array $data) {
        if (request()->user()->cannot('create', Depense::class)) {
            throw new DepenseException('You are not authorized to create this depense', 403);
        }
        return Depense::create($data);
    }

    public function update(array $data, int $id) {
        if (request()->user()->cannot('update', Depense::findOrFail($id))) {
            throw new DepenseException('You are not authorized to update this depense', 403);

        }
        $depense = Depense::findOrFail($id);
        $depense->update($data);
        return $depense;
    }

    public function show(int $id) {
        if (request()->user()->cannot('view', Depense::findOrFail($id))) {
            throw new DepenseException('You are ara not authorized to show this depense', 403);

        }
        return Depense::findOrFail($id);
    }

    public function delete(int $id) {
        if (request()->user()->cannot('delete', Depense::findOrFail($id))) {
            throw new DepenseException('You are not authorized to delete this depense', 403);
        }
        Depense::destroy($id);
    }
}
