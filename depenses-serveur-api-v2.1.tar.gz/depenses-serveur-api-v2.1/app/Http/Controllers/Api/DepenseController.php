<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\DepenseException;
use App\Http\Requests\DepenseRequest;
use App\Http\Resources\DepenseResource;
use App\Models\Depense;
use App\Repositories\DepenseRepository;

class DepenseController extends BaseController {

    protected DepenseRepository $repository;

    public function __construct(DepenseRepository $repository) {
        $this->repository = $repository;
    }

    /**
     * Retrieve all depenses associated with a given Personne ID.
     *
     * @param int $id The ID of the Personne whose depenses are to be retrieved.
     * @return \Illuminate\Http\JsonResponse A JSON response containing the depenses or an error message.
     */
    public function depensesOfPersonneId($id) {
        try {
            $depenses = $this->repository->depensesOfPersonneId($id);
        } catch (DepenseException $e) {
            return $this->sendError('Depenses not found', ['error' => $e->getMessage()], $e->getCode());
        }
        $success = ['depenses' => DepenseResource::collection($depenses)];
        return $this->sendResponse($success, 'Depenses retrieved successfully');
    }

    /**
     * Store a newly created Depense model.
     *
     * @param \App\Http\Requests\DepenseRequest $request The request object containing the data for the new Depense.
     * @return \Illuminate\Http\JsonResponse A JSON response containing the newly created Depense model.
     */
    public function store(DepenseRequest $request) {
        if ($request->user()->cannot('create', Depense::class)) {
            return $this->sendError('Depense not created', ['error' => 'You are are not authorized to create this depense'], 403);
        }
        try {
            $depense = $this->repository->store($request->all());
        } catch (DepenseException $e) {
            return $this->sendError('Depense not created', ['error' => $e->getMessage()], $e->getCode());
        }
        $success = ['depense' => new DepenseResource($depense)];
        return $this->sendResponse($success, 'Depense created successfully');
    }

    /**
     * Update an existing Depense model by its ID.
     *
     * @param \App\Http\Requests\DepenseRequest $request The request object containing the data for the Depense.
     * @param int $id The ID of the Depense to update.
     * @return \Illuminate\Http\JsonResponse A JSON response containing the updated Depense model.
     */
    public function update(DepenseRequest $request, $id) {
        try {
            $depense = $this->repository->update($request->all(), $id);
        } catch (DepenseException $e) {
            return $this->sendError('Depense not updated', ['error' => $e->getMessage()], $e->getCode());
        }

        $success = ['depense' => new DepenseResource($depense)];
        return $this->sendResponse($success, 'Depense updated successfully');
    }

    /**
     * Delete a Depense model by its ID.
     *
     * @param int $id The ID of the Depense to delete.
     * @return \Illuminate\Http\JsonResponse A JSON response indicating the result of the deletion.
     */
    public function destroy($id) {
        try {
            $this->repository->delete($id);
        } catch (DepenseException $e) {
            return $this->sendError('Depense not deleted', ['error' => $e->getMessage()], $e->getCode());
        }

        return $this->sendResponse([], 'Depense deleted successfully');
    }

    public function show(int $id) {
        try {
            $depense = $this->repository->show($id);
        } catch (DepenseException $e) {
            return $this->sendError('Depense not showed', ['error' => $e->getMessage()], $e->getCode());
        }
        $success = ['depense' => new DepenseResource($depense)];
        return $this->sendResponse($success, 'Depense retrieved successfully');
    }
}
