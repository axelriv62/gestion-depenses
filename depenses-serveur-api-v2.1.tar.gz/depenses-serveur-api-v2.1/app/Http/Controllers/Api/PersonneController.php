<?php

namespace App\Http\Controllers\Api;

use App\Exceptions\PersonneNotFoundException;
use App\Http\Resources\PersonneResource;
use App\Repositories\PersonneRepository;
use Illuminate\Http\Request;


class PersonneController extends BaseController {

    private $repository;

    public function __construct(PersonneRepository $repository) {
        $this->repository = $repository;
    }

    /**
     * Retrieve a collection of Personne models based on the request parameters.
     *
     * @param \Illuminate\Http\Request $request The request object containing the parameters.
     *                                          - 'sort' (string): The column to sort by.
     *                                          - 'order' (string): The sort direction ('asc' or 'desc').
     *                                          - 'search' (string): A search term to filter by the 'nom' column.
     *                                          - 'horsLimite' (bool): If set, filters Personne models where the sum of related 'depenses' is less than the 'plafond'.
     * @return \Illuminate\Http\JsonResponse A JSON response containing the collection of Personne models.
     */
    public function index(Request $request) {
        $collection = $this->repository->getPersonnes($request->only(['sort', 'order', 'horsLimite', 'search']));
        $success = ['personnes' => PersonneResource::collection($collection)];
        return $this->sendResponse($success, 'Personnes retrieved successfully');
    }

    /**
     * Retrieve a Personne model by its ID.
     *
     * @param int $id The ID of the Personne to retrieve.
     * @return \Illuminate\Http\JsonResponse A JSON response containing the Personne model or an error message.
     */
    public function show(int $id) {
        try {
            $personne = $this->repository->getPersonne($id);
        } catch (PersonneNotFoundException $e) {
            return $this->sendError('Personne not found', ['error' => 'Personne not found'], 404);
        }
        $success = ['personne' => new PersonneResource($personne)];
        return $this->sendResponse($success, 'Personne retrieved successfully');
    }
}
