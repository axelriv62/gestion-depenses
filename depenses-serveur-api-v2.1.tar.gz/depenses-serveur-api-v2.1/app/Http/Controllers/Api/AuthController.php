<?php

namespace App\Http\Controllers\Api;

use App\Http\Requests\PersonneRequest;
use App\Http\Resources\PersonneResource;
use App\Http\Resources\UserResource;
use App\Models\Personne;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class AuthController extends BaseController {

    /**
     * Handle the registration request.
     *
     * @param Request $request The incoming request instance.
     * @return JsonResponse The response containing the newly registered user data or error message.
     */
    public function register(PersonneRequest $request): JsonResponse {
        $validatedData = $request->validated();

        try {
            DB::Transaction(function () use ($validatedData, &$user, &$personne) {
                $email = Str::of(strtolower($validatedData['prenom']) . '.' . strtolower($validatedData['nom']) . '@domain.fr')->ascii();
                $rules = ['email' => 'unique:users,email'];
                $input = ['email' => $email];
                if(!Validator::make($input, $rules, ['unique' => 'L\'adresse mail est déjà utilisée'])->passes()) {
                    throw new \Exception('Email already exists.');
                }
                $user = User::create([
                    'name' => $validatedData['prenom'] . ' ' . $validatedData['nom'],
                    'email' => $email,
                    'password' => Hash::make($validatedData['password']),
                ]);
                $personne = Personne::create([
                    'nom' => $validatedData['nom'],
                    'prenom' => $validatedData['prenom'],
                    'plafond' => $validatedData['plafond'],
                    'user_id' => $user->id,
                ]);
            });
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->sendError('Error.', ['error' => $e->getMessage()], 422);
        }


        $success['token'] = $user->createToken('auth_token')->plainTextToken;
        $success['token_type'] = 'Bearer';
        $success['personne'] = new PersonneResource($personne);

        return $this->sendResponse($success, 'Personne register successfully.');
    }

    /**
     * Handle the login request.
     *
     * @param Request $request The incoming request instance.
     * @return JsonResponse The response containing the authentication token or error message.
     */
    public function login(Request $request): JsonResponse {
        if (!Auth::attempt($request->only('email', 'password'))) {
            return $this->sendError('Unauthorised.', ['error' => 'Unauthorised'], 401);
        }

        $user = Auth::user();
        $success['user'] = new UserResource($user);
        $success['token'] = $user->createToken('auth_token')->plainTextToken;
        $success['token_type'] = 'Bearer';

        return $this->sendResponse($success, 'User login successfully.');
    }

    /**
     * Get the authenticated user's information.
     *
     * @param Request $request The incoming request instance.
     * @return JsonResponse The response containing the authenticated user's information.
     */
    public function me(Request $request): JsonResponse {
        $personne = $request->user()->personne;
        if ($personne) {
            $success['personne'] = new PersonneResource($personne);
            return $this->sendResponse($success, 'User information.');
        }
        $success['user'] = new UserResource(Auth::user());
        return $this->sendResponse($success, 'User information.');
    }

    /**
     * Handle the logout request.
     *
     * @return JsonResponse The response confirming the user has been logged out.
     */
    public function logout(): JsonResponse {
        auth()->user()->tokens()->delete();
        return $this->sendResponse([], 'Logged out successfully.');
    }

    public function refresh() {
        $success['token'] = Auth::user()->createToken('auth_token')->plainTextToken;
        $success['token_type'] = 'Bearer';
        $success['user'] = Auth::user();
        return $this->sendResponse($success, 'User token refresh information.');
    }

}
