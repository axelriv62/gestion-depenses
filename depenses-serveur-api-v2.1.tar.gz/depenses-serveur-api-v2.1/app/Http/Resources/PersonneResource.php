<?php

namespace App\Http\Resources;

use App\Models\Depense;
use App\Repositories\DepenseRepository;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PersonneResource extends JsonResource {

    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array {
        $repo = app(DepenseRepository::class);
        return [
            'id' => $this->id,
            'nom' => $this->nom,
            'prenom' => $this->prenom,
            'plafond' => $this->plafond,
            'user' => new UserResource($this->user),
            'montantDepenses' => $repo->montantDepensesOfPersonneId($this->id),
        ];
    }
}
