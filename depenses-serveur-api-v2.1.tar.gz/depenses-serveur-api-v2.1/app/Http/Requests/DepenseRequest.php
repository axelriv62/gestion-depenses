<?php

namespace App\Http\Requests;

use App\Enums\NatureEnum;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class DepenseRequest extends FormRequest {
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array {
        return [
            'personne_id' => 'required',
            'libelle' => 'required|max:255',
            'montant' => 'required|numeric',
            'dd' => 'required|date',
            'nature' => ['required', Rule::in(NatureEnum::toValuesArray())]
        ];
    }

    /**
     * Get the error messages for the defined validation rules.
     *
     * @return array<string, string>
     */
    public function messages(): array {
        return [
            'required' => 'Le champ :attribute est obligatoire.',
            'max' => 'Le champ :attribute doit contenir au maximum :max caractères.',
            'numeric' => 'Le champ :attribute doit être un nombre.',
            'date' => 'Le champ :attribute doit être une date.',
            'in' => 'La valeur du champ nature doit prendre une valeur dans ' . implode(",", NatureEnum::toValuesArray()) . '.',
        ];
    }

}
