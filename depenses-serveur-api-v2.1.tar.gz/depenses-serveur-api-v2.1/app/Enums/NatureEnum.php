<?php

namespace App\Enums;

enum NatureEnum: string {
    case AUTRE = "Autre";
    case ALIMENTAIRE = "Alimentaire";
    case LOISIR = "Loisirs";
    case VOITURE = "Voiture";
    case HABITAT = "Habitat";
    case SPORT = "Sport";
    case VACANCES = "Vacances";

    public static function toArray(): array {
        return [
            self::AUTRE,
            self::ALIMENTAIRE,
            self::LOISIR,
            self::VOITURE,
            self::HABITAT,
            self::SPORT,
            self::VACANCES,
        ];
    }

    public static function toValuesArray(): array {
        return array_map(fn($value) => $value->value, self::toArray());
    }
}
