<?php

namespace Database\Seeders;

use App\Models\Depense;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

class DepenseSeeder extends Seeder {
    /**
     * Run the database seeds.
     */
    public function run(): void {
        $depenses = Storage::json('json/depenses.json');
        foreach ($depenses as $value) {
            Depense::create([
                'montant' => $value["montant"],
                'dd' => $value["dd"],
                'nature' => $value["nature"],
                'libelle' => $value["libelle"],
                'personne_id' => $value["personne_id"],
            ]);
        }

    }
}
