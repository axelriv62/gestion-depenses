<?php

namespace Database\Seeders;

use App\Models\Personne;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class PersonneSeeder extends Seeder {
    /**
     * Run the database seeds.
     */
    public function run(): void {
        $personnes = Storage::json('json/personnes.json');
        foreach ($personnes as $value) {
            $personne = Personne::make([
                'nom' => $value["nom"],
                'prenom' => $value["prenom"],
                'plafond' => $value["plafond"],
            ]);
            $user = User::factory()->create([
                'name' => $value["prenom"] . ' ' . $value["nom"],
                'email' => Str::of(strtolower($value["prenom"] . '.' . strtolower($value["nom"]) . '@domain.fr'))
                    ->ascii(),
            ]);
            $personne->user_id = $user->id;
            $personne->save();;
        }
    }
}
