# Serveur API de l'application Gestion de dépenses  

## Système d'information

![](./public/docs/systeme-info.png)

## Base de données

Utilisation d'une base de données `sqlite` (plus simple), mais d'autres choix peuvent être utilisé (mysql, postgresql, ...).

Il faut créer un fichier `.env` à partir du fichier `.env.example`

Dans le fichier `.env` que vous venez de récupérer, vous trouverez une _config_ pour l'utilisation d'une BD `sqlite`

## Pour lancer le serveur

```shell
composer update
cp .env.example .env
php artisan key:generate   

php artisan migrate --seed
# Les fois suivantes 
php artisan migrate:fresh --seed
# et   
php artisan serve 
```
