<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\DepenseController;
use App\Http\Controllers\Api\PersonneController;
use Illuminate\Support\Facades\Route;

Route::controller(AuthController::class)->group(function () {
    Route::post('login', 'login')->name('login');
    Route::post('register', 'register')->name('register');
    Route::post('logout', 'logout')->name('logout');
    Route::post('refresh', 'refresh')->name('refresh');
    Route::get('me', 'me')->name('profil');
});

Route::prefix('personnes')->middleware('auth:sanctum')->group(function () {
    Route::get('/', [PersonneController::class, 'index'])->name('personnes.index');
    Route::get('/{id}', [PersonneController::class, 'show'])->name('personnes.show');
});

Route::prefix('depenses')->middleware('auth:sanctum')->group(function () {
    Route::get('/personne/{id}', [DepenseController::class, 'depensesOfPersonneId'])->name('depenses.personne');
    Route::get('/{id}', [DepenseController::class, 'show'])->name('depenses.show');
    Route::put('/{id}', [DepenseController::class, 'update'])->name('depenses.update');
    Route::post('/', [DepenseController::class, 'store'])->name('depenses.store');
    Route::delete('/{id}', [DepenseController::class, 'destroy'])->name('depenses.destroy');
});
